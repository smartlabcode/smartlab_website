<?php

return [
	'first_item' => 'Sta mi radimo2',
	'second_item' => 'Ko smo mi',
	'third_item' => 'Pridruzite nam se',
	'fourth_item' => 'Blog',
	'fifth_item' => 'Kontakt',
	'sixth_item' => 'Dashboard',
	'tenth_item' => 'Izloguj se',
	'english_language' => 'Engleski',
	'german_language' => 'Njemački',
	'bosnian_language' => 'Bosanski',
];