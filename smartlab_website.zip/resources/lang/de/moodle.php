<?php
return [
    "MoodleLMS" => "Implementierung des
    Moodle LMS-Systems",
    "secOneP1" => "Wir nutzen das führende Open Source Learning Management.
    System Moodle, das vollständig anpassbare Funktionen bietet, um
    private Websites mit Online-Kursen erstellen.",
    "secOneUlFirst" => "Starke Community, die ständig neue Wege geht.
    Lösungen für verschiedene Herausforderungen",
    "secOneUlSecond" => "Erstellen Sie Ihr Thema online mit den Produkten Ihres Unternehmens Markenidentität",
    "secOneUlThird" => "Starke Berichts- und Verfolgungsoptionen ",
    "secOneUlFourth" => "Vollständig anpassbar an verschiedene Geräte",
    "sec2h2" => "Unsere Arbeiten",
    "sec2h22" => "Ich möchte mehr sehen:",
    "buttonSchedule" => "Planen Sie eine Demo",
    "sec3h2" => "Tools und Technologien",
    "sec3p" => "Moodle ist eine Open-Source-Software 
    und eventuell verschiedene Außenanwendungen 
    zu integrieren Features ist ein großer Vorteil",
    "contact" => "Kontakt",
    "contactName" => "*Vorname und Nachname",
    "contactCompany" => "*Unternehmen",
    "contactSubject" => "*Betreff",
    "contactEmail" => "*E-mail",
    "contactDate" => "*Versammlungstermin",
    "contactTime" => "*Besprechungszeit",
    "contactMessage" => "*Nachricht",
    "buttonSend" => "Senden"



];
