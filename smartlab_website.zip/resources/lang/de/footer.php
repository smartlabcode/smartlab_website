<?php

return [
    "state" => "Bosnien und Herzegowina",
    "findUs" => "Finden Sie uns"
];