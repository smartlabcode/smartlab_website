<?php

return [
  'first_item' => 'Was machen wir',
  'second_item' => 'Wer sind wir',
  'third_item' => 'Komm mit uns',
  'fourth_item' => 'Blog',
  'fifth_item' => 'Kontakt',
  'sixth_item' => 'Dashboard',
  'tenth_item' => 'Ausloggen',
  'online_courses' => 'Online Kurse',
  'educational_video' => 'Bildungsvideoanimation',
  'programming' => 'Programmierung',
  'moodle' => 'Moodle',
  'about_us' => 'Über uns',
  'our_team' => 'Unser Team',
  'outsourcing' => 'Outsourcing',
  'become_a_partner' => 'Werden Sie Partner',
  'careers' => 'Karrieren',
  'english_language' => 'En',
  'german_language' => 'De',
  'bosnian_language' => 'Ba'
];
