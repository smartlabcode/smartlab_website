<?php
return [
    "animations" => "Edukations-Videoanimations-Inhalte",
    "secOneP1" => "Unterhalten und bilden Sie Ihre Teilnehmer mit unseren attraktiven und interessanten animierten Video-Spots. Stellen Sie Ihre Produkte vor, vermitteln Sie Ihr Wissen Ihren Teilnehmern und erklären Sie Ihren Arbeitsablauf mit interaktiven Multimedia-Inhalten.",
    "secOneUlFirst" => "Wandeln Sie Ihre schriftlichen Anleitungen und Handbücher in Multimedia-Video-Tutorials um",
    "secOneUlSecond" => "Einführungs-Video für Ihre Dienstleistungen und komplexe Funktionen ",
    "secOneUlThird" => "Animierte Videos auf “Whiteboards”",
    "secOneUlFourth" => "Erstellung von speziellen Effekten für den Inhalt von interaktiven Lernspielen",
    "sec2h2" => "Unsere Arbeit",
    "sec2h22" => "Wollen Sie mehr sehen:",
    "buttonSchedule" => "Wollen Sie mehr sehen:",
    "sec3h2" => "Werkzeuge und Technologien",
    "sec3p" => "Die Videoproduktion aus der eLearning-Perspektive bedeutet die Erstellung von Funktionen, die ein Video in interaktive Lerninhalte umwandeln können. Das ist ein Schritt nach vorne, um den Teilnehmer-Fokus zu wahren.",
    "contact" => "Contact us",
    "contactName" => "*Vorname und Nachname",
    "contactCompany" => "*Unternehmen",
    "contactSubject" => "*Betreff",
    "contactEmail" => "*E-mail",
    "contactDate" => "*Versammlungstermin",
    "contactTime" => "*Besprechungszeit",
    "contactMessage" => "*Nachricht",
    "buttonSend" => "Senden"

];
