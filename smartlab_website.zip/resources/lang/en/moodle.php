<?php
return [
    "MoodleLMS" => "Moodle
    LMS Implementation ",
    "secOneP1" => "We use the leading open source learning management system Moodle which offers fully customisable features to create private websites with online courses.",
    "secOneUlFirst" => "A strong community which constantly finds new solutions for different challenges",
    "secOneUlSecond" => "Create your  theme in accordance with your company’s brand identity",
    "secOneUlThird" => "Strong reporting and tracking options",
    "secOneUlFourth" => "Fully adaptable to different devices",
    "sec2h2" => "Our Works",
    "sec2h22" => "Want to see more:",
    "buttonSchedule" => "Schedule a demo",
    "sec3h2" => "Tools and Technologies",
    "sec3p" => "Moodle is Open Source software and the possibility of integrating different outside features is a big advantage.",
    "contact" => "Contact",
    "contactName" => "*Name and Surname",
    "contactCompany" => "*Company",
    "contactSubject" => "*Subject",
    "contactEmail" => "*E-mail",
    "contactDate" => "*Meeting date",
    "contactTime" => "*Meeting time",
    "contactMessage" => "*Message",
    "buttonSend" => "Send"



];
