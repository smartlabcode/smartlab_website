<?php
return [
    "oops" => "OOPS",
    "h1" => "There is only a 500 error
    message ahead",
    "back" => "Back to home"


];