<?php

return [
    "state" => "Bosnia and Herzegovina",
    "findUs" => "Find us"
];