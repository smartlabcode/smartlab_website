<?php

return [
    'first_item' => 'What we do',
    'second_item' => 'Who we are',
    'third_item' => 'Join us',
    'fourth_item' => 'Blog',
    'fifth_item' => 'Contact',
    'sixth_item' => 'Dashboard',
    'tenth_item' => 'Log out',
    'online_courses' => 'Online Courses',
    'educational_video' => 'Educational Video Animation',
    'programming' => 'Programming',
    'moodle' => 'Moodle',
    'about_us' => 'About Us',
    'our_team' => 'Our Team',
    'outsourcing' => 'Outsourcing',
    'become_a_partner' => 'Become A Partner',
    'careers' => 'Careers',
    'english_language' => 'En',
    'german_language' => 'De',
    'bosnian_language' => 'Ba'
];
