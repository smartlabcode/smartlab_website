<?php

return [
    "state" => "Bosna i Hercegovina",
    "findUs" => "Pronađite nas"
];