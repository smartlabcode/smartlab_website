<?php
return [
    "MoodleLMS" => "Implementacija
    Moodle LMS sistema",
    "secOneP1" => "Koristimo Moodle kao vodeći “Open Source” sistem za upravljanje učenjem. On nudi potpuno prilagodljive alate za kreiranje personalnih web-sadržaja sa online kursevima.",
    "secOneUlFirst" => "Jaka zajednica koja stalno pronalazi nova rješenja za različite izazove",
    "secOneUlSecond" => "Kreirajte  temu u skladu sa identitetom vaše kompanije",
    "secOneUlThird" => "Snažne opcije za izvještavanje i praćenje sadržaja učenja",
    "secOneUlFourth" => "Potpuno prilagodljiv različitim uređajima",
    "sec2h2" => "Naši radovi",
    "sec2h22" => "Želite vidjeti više:",
    "buttonSchedule" => "Zakažite demo",
    "sec3h2" => "Alati i tehnologije",
    "sec3p" => "Moodle je “Open Source” softver i velika prednost je mogućnost integracije različitih vanjskih elemenata.",
    "contact" => "Kontakt",
    "contactName" => "*Ime i Prezime",
    "contactCompany" => "*Kompanija",
    "contactSubject" => "*Predmet",
    "contactEmail" => "*E-mail",
    "contactDate" => "*Datum sastanka",
    "contactTime" => "*Vrijeme sastanka",
    "contactMessage" => "*Poruka",
    "buttonSend" => "Pošalji"

];
