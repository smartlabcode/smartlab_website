<?php
return [
    "Animation" => "Edukacijski video animirani sadržaji",
    "secOneP1" => "Zabavite i edukujte svoje polaznike našim privlačnim i zanimljivim animiranim video spotovima. Predstavite svoje proizvode, prenesite znanje svojim polaznicima i objasnite svoj radni proces uz pomoć interaktivnog multimedijalnog sadržaja.",
    "secOneUlFirst" => "Konvertovanje vaših pisanih uputstava i priručnika u multimedijalne video tutorijale",
    "secOneUlSecond" => "Uvodni video za vaše usluge i složene funkcije",
    "secOneUlThird" => "Animirani video zapisi na ‘bijeloj tabli’",
    "secOneUlFourth" => "Stvaranje posebnih efekata za sadržaj interaktivnih igara za učenje",
    "sec2h2" => "Naši radovi",
    "sec2h22" => "Želite vidjeti više:",
    "buttonSchedule" => "Zakažite demo",
    "sec3h2" => "Alati i tehnologije",
    "sec3p" => "Video produkcija iz eLearning perspektive predstavlja kreiranje funkcija koje mogu konvertovati video zapis u interaktivni sadržaj za učenje. To je korak naprijed u zadržavanju fokusa polaznika.",
    "contact" => "Contact us",
    "contactName" => "*Ime i Prezime",
    "contactCompany" => "*Kompanija",
    "contactSubject" => "*Predmet",
    "contactEmail" => "*E-mail",
    "contactDate" => "*Datum sastanka",
    "contactTime" => "*Vrijeme sastanka",
    "contactMessage" => "*Poruka",
    "buttonSend" => "Pošalji"



];
