<?php

return [
	'first_item' => 'Sta mi radimo',
	'second_item' => 'Ko smo mi',
	'third_item' => 'Pridruzite nam se',
	'fourth_item' => 'Blog',
	'fifth_item' => 'Kontakt',
	'sixth_item' => 'Dashboard',
	'tenth_item' => 'Izloguj se',
	'online_courses' => 'Online kursevi',
	'educational_video' => 'Obrazovna video animacija',
	'programming' => 'Programiranje',
	'moodle' => 'Moodle',
	'about_us' => 'O name',
	'our_team' => 'Naš tim',
	'outsourcing' => 'Outsourcing',
	'become_a_partner' => 'Postanite partner',
	'careers' => 'Karijere',
	'english_language' => 'En',
	'german_language' => 'De',
	'bosnian_language' => 'Ba'
];
