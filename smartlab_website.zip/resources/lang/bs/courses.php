<?php

return [
    "onlineCourses" => "Online kursevi",
    "secOneP1" => "Dizajniramo i razvijamo eLearning sadržaj od samog početka i implementiramo vaše ideje u visoko kvalitetne i zanimljive kurseve. Pomažemo vam da maksimalno povećate prihode od ulaganja u obuku, zbog toga su naši kursevi  napravljeni da poboljšaju rezultate rada vaših zaposlenih i smanje troškove obuke.",
    "secOneUlFirst" => "Prilagodljivi i odgovarajući kursevi",
    "secOneUlSecond" => "“Mikroučenje” pomoću animiranih video zapisa",
    "secOneUlThird" => "Učenje pomoću simulacije scenarija",
    "secOneUlFourth" => "Iskustvo sa interaktivnim igrama za učenje",
    "sec2h2" => "Naši radovi",
    "sec2h22" => "Želite vidjeti više:",
    "buttonSchedule" => "Zakažite demonstraciju ",
    "sec3h2" => "Alati i tehnologije",
    "sec3p" => "Koristeći razne alate i tehnologije, dizajniramo prilagođene eLearning kurseve, koji su usklađeni sa vašim strateškim poslovnim ciljevima.",
    "contactName" => "*Ime i Prezime",
    "contactCompany" => "*Kompanija",
    "contactSubject" => "*Predmet",
    "contactEmail" => "*E-mail",
    "contactDate" => "*Datum sastanka",
    "contactTime" => "*Vrijeme sastanka",
    "contactMessage" => "*Poruka",
    "buttonSend" => "Pošalji"

];
