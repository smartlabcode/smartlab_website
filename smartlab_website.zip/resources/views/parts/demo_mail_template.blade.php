

<div>

    <p>Name and surname: {{$data['name']}}</p>
    <p>Company: {{$data['company']}}</p>
    <p>Email: {{$data['email']}}</p>
    <p>Subject: {{$data['subject']}}</p>
    <p>Message: {{$data['message']}}</p>
    <p>Date: {{$data['date']}}</p>
    <p>Time: {{$data['time']}}</p>

</div>