<div>
    <p>Company: {{$data['company']}}</p>
    <p>Bussiness website: {{$data['bussiness_website']}}</p>
    <p>Bussiness person: {{$data['bussiness_person']}}</p>
    <p>Email: {{$data['email']}}</p>
    <p>Phone number: {{$data['phone_number']}}</p>
    <p>Message: {{$data['message']}}</p>
    <p>Category: {{$data['category']}}</p>
</div>