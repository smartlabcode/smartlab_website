<div>
    <p>Name: {{$data['name']}}</p>
    <p>Surname: {{$data['lastname']}}</p>
    <p>Email: {{$data['email']}}</p>
    <p>Phone number: {{$data['phone_number']}}</p>
    <p>Subject: {{$data['subject']}}</p>
    <p>Category: {{$data['category']}}</p>
    <p>Message: {{$data['message']}}</p>
</div>