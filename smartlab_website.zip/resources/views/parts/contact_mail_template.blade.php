
<!-- Contact person info -->
<div>

    <p>Name: {{$data['name']}}</p>
    <p>Lastname: {{$data['lastname']}}</p>
    <p>Email: {{$data['email']}}</p>
    <p>Subject: {{$data['subject']}}</p>
    <p>Message: {{$data['message']}}</p>

</div>