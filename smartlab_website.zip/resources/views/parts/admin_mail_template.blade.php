
<!-- New admin info -->
<div>
    <p>Username: {{$email}}</p>
    <p>Password: {{$password}}</p>
</div>